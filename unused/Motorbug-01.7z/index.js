
var canvi = document.getElementById("myCanvas");

var c = canvi.getContext("2d");

canvi.style.position = "absolute";
canvi.style.top = "0px";
canvi.style.left = "0px";
canvi.style.border = "1px solid black";

var keysDown = [];
var sonicImage = document.createElement("img");
sonicImage.src = "SonicSheet.png";
sonicImage.style.imageRendering = "pixelated";
canvi.width = sonicImage.width;
canvi.height = sonicImage.height;
var sonicSpinImage = document.createElement("img");
sonicSpinImage.src = "sonicJumping.png"

var levelImage = document.createElement("img");
levelImage.src = "testLevel.png";

var sonicCanvas = document.createElement("canvas");
sonicCanvas.width = 40;
sonicCanvas.height = 40;
var sc = sonicCanvas.getContext("2d");

function grabAnim(startx,starty,W,H,n){
	//c.clearRect(0,0,window.innerWidth, window.innerHeight);
	//c.drawImage(sonicImage,0,0);
	var images = [];
	for(var i = 0; i<n; i++){
		images[i] = [startx+W*i,starty,W,H];
	}
	return images;
}

var anim = {
	stand:grabAnim(8,17,40,40,1),
	jog:grabAnim(8,65,44,40,8),
	run:grabAnim(360,70,40,34,4),
	jump:grabAnim(8,337,40,30,5),
	skid:grabAnim(8,378,40,40,1),
	crouch:grabAnim(160,26,30,30,1),
	spindash:grabAnim(208,341,40,30,6)
}
//console.log(images1);

var interval = window.setInterval(loop,17);
var char = {
	x:800,
	y:50,
	xv:0,
	yv:0,
	grounded: false,
	frameIndex:0,
	currentAnim:anim.stand,
	animSpeed:0.5,
	rolling: false,
	angle:0
};

var color = [0,0,0,0];
var timer = 0;

function loop(){
	timer++;
	//char.angle += 0.01;
	canvi.width = window.innerWidth-2;
	canvi.height = window.innerHeight-2;
	c.fillStyle = "#9999FF";
	c.fillRect(0,0,window.innerWidth, window.innerHeight);

	c.imageSmoothingEnabled = false;
	c.drawImage(levelImage,0,0,levelImage.width*2,levelImage.height*2);
	color = c.getImageData(char.x,char.y,1,1).data;
	char.frameIndex += char.animSpeed;
	if(char.frameIndex>char.currentAnim.length-1){char.frameIndex = 0;}
	
	/*var collisionPoint = [-1,-1];
	color = c.getImageData(char.x,char.y,1,1).data;
	if(color[0] == 0 && color[1] == 0 && color[2] == 0){
		var going = true;
		var i = 0;
		while(going){
			i++;
			color1 = c.getImageData(char.x,char.y-i,1,1).data;
			if(color1[0] != 0 || color1[1] != 0 || color1[2] != 0){
				collisionPoint = [char.x,char.y-i];
				going = false;	
			}
		}
	}*/
	if(char.grounded&&timer%2 == 0){
		//determine ground angle - PT 1
		var loc1 = {x:Math.floor(char.x),y:Math.floor(char.y)};
		var going = true;
		var i = -10;
		collisionPts = [];
		color1 = c.getImageData(loc1.x+Math.cos(char.angle)*-10-Math.sin(char.angle)*15,loc1.y+Math.cos(char.angle)*15+Math.sin(char.angle)*-10,1,1).data;
		if(color1[0] == 0 && color1[1] == 0 && color1[2] == 0){
			while(going){
				i += 2;
				color1 = c.getImageData(loc1.x+Math.cos(char.angle)*-10-Math.sin(char.angle)*-i,loc1.y+Math.cos(char.angle)*-i+Math.sin(char.angle)*-10,1,1).data;
				if(color1[0] != 0 || color1[1] != 0 || color1[2] != 0){
					// change point = [-10,-i]
					collisionPts[0] = [loc1.x+Math.cos(char.angle)*-10-Math.sin(char.angle)*-i,loc1.y+Math.cos(char.angle)*-i+Math.sin(char.angle)*-10];
					//c.fillStyle = "#FF0000";
					//c.fillRect(collisionPts[0][0],collisionPts[0][1],3,3);
					going = false;
				}
				else
				{
					c.fillStyle = "#00FF00"
					c.fillRect(loc1.x+Math.cos(char.angle)*-10-Math.sin(char.angle)*-i,loc1.y+Math.cos(char.angle)*-i+Math.sin(char.angle)*-10,1,1);
				}
			}
			going = true;
		}
		else
		{
			char.grounded = false;
			char.yv = Math.cos(char.angle)*char.yv+Math.sin(char.angle)*char.xv;
			char.xv = Math.cos(char.angle)*char.xv-Math.sin(char.angle)*char.yv;
			char.angle = 0;
			char.rolling = false;
			going = false;
		}
		//determine ground angle - PT 2
		
		var i = -10;
		color1 = c.getImageData(loc1.x+Math.cos(char.angle)*-10-Math.sin(char.angle)*15,loc1.y+Math.cos(char.angle)*15+Math.sin(char.angle)*-10,1,1).data;
		if(color1[0] == 0 && color1[1] == 0 && color1[2] == 0 && char.grounded){
			while(going){
				i += 2;
				color1 = c.getImageData(loc1.x+Math.cos(char.angle)*10-Math.sin(char.angle)*-i,loc1.y+Math.cos(char.angle)*-i+Math.sin(char.angle)*10,1,1).data;
				
				if(color1[0] != 0 || color1[1] != 0 || color1[2] != 0){
					collisionPts[1] = [loc1.x+Math.cos(char.angle)*10-Math.sin(char.angle)*-i,loc1.y+Math.cos(char.angle)*-i+Math.sin(char.angle)*10];
					//console.log(collisionPts[1][0]+","+collisionPts[1][0])
					//c.fillStyle = "#FF0000";
					//c.fillRect(collisionPts[1][0],collisionPts[1][1],3,3);
					x = -1;
					going = false;
				}
				else
				{
					c.fillStyle = "#00FF00"
					c.fillRect(loc1.x+Math.cos(char.angle)*10-Math.sin(char.angle)*-i,loc1.y+Math.cos(char.angle)*-i+Math.sin(char.angle)*10,1,1);
				}
			}
		}
		else
		{
			char.grounded = false;
			char.yv = Math.cos(char.angle)*char.yv+Math.sin(char.angle)*char.xv;
			char.xv = Math.cos(char.angle)*char.xv-Math.sin(char.angle)*char.yv;
			char.angle = 0;
			char.rolling = false;
			going = false;
		}
		if(char.grounded){
			char.y += (((collisionPts[0][1]+collisionPts[1][1])/2)-char.y)*Math.cos(char.angle);
			char.x += (char.x-((collisionPts[0][0]+collisionPts[1][0])/2))*Math.sin(char.angle);
			char.angle = (collisionPts[0][0]-collisionPts[1][0]) == 0?Math.PI/2*char.angle/Math.abs(char.angle):Math.atan((collisionPts[0][1]-collisionPts[1][1])/(collisionPts[0][0]-collisionPts[1][0]));
			console.log(char.angle);
		}
	}
	
	//draw Character
	var a = char.currentAnim[Math.floor(char.frameIndex)][3]/2*((char.xv<0)?1:-1);
	var b = -(char.currentAnim[Math.floor(char.frameIndex)][3]-2)
	c.translate(char.x+a*Math.cos(char.angle)-b*Math.sin(char.angle),char.y+b*Math.cos(char.angle)+a*Math.sin(char.angle));
	c.rotate(char.angle);
	if(char.xv < 0){
		c.scale(-1,1);
	}
	
	//c.translate(90,90);
	
	//draw sonic
	sonicCanvas.width = char.currentAnim[Math.floor(char.frameIndex)][2];
	sonicCanvas.height = char.currentAnim[Math.floor(char.frameIndex)][3];
	sc.drawImage(sonicImage,-char.currentAnim[Math.floor(char.frameIndex)][0],-char.currentAnim[Math.floor(char.frameIndex)][1])
	c.drawImage(sonicCanvas,0,0);
	//c.fillRect(0,0,50,50);
	c.setTransform(1,0,0,1,0,0);
	/*c.fillStyle = "#000000"				//Debugging helpers
	c.fillRect(0,200,window.innerWidth,2);
	c.fillStyle = "#FF0000";
	c.fillRect(char.x-1,char.y-1,3,3);*/
	
	//velocity
	char.x += Math.cos(char.angle)*char.xv-Math.sin(char.angle)*char.yv;
	char.y += Math.cos(char.angle)*char.yv+Math.sin(char.angle)*char.xv;
	
	//gravity
	if(char.grounded == false){
		char.yv += 0.5;
	}

	//basic floor
	if(color[0] == 0 && color[1] == 0 && color[2] == 0){
		//char.y = 200;
		char.yv = 0;
		char.grounded = true;
	}


	if(keysDown[32] && char.grounded){
		if(keysDown[40] != true){
			char.grounded = false;
			char.yv = -10*Math.cos(char.angle);
			char.xv = -10*Math.sin(char.angle);
			char.angle = 0;
			char.rolling = false;
		}
	}

	if(char.rolling == false){
		if(keysDown[39]){
			if(char.xv < 10){
				char.xv += 0.07;
			}
			if(char.xv < 0){
				char.xv += 1;
				char.currentAnim = anim.skid;
			}
			else
			{
				if(Math.abs(char.xv)>8){
					char.currentAnim = anim.run;
				}
				else{
					char.currentAnim = anim.jog;
					char.animSpeed = Math.abs(char.xv)/20+0.1;
				}
			}
		}
		else if(keysDown[37]){
			if(char.xv > -10){
				char.xv -= 0.07;
			}
			if(char.xv > 0){
				char.xv -= 1;
				char.currentAnim = anim.skid;
			}
			else
			{
				if(Math.abs(char.xv)>8){
					char.currentAnim = anim.run;
				}
				else{
					char.currentAnim = anim.jog;
					char.animSpeed = Math.abs(char.xv)/20+0.1;
				}
			}
		}
		else
		{
			if(char.xv > 0.001){
				char.xv -= 0.2;
			}
			else if(char.xv < -0.001){
				char.xv += 0.2;
			}
			if(char.xv > -0.2 && char.xv < 0.2 && char.xv != 0){
				char.xv = 0.0001*(char.xv/Math.abs(char.xv));
			}
			
			if(Math.abs(char.xv) <= 0.01){
				char.currentAnim = anim.stand;
			}
			else
			{
				if(Math.abs(char.xv)>8){
					char.currentAnim = anim.run;
				}
				else{
					char.currentAnim = anim.jog;
					char.animSpeed = Math.abs(char.xv)/20+0.1;
				}
			}
		}
		if(keysDown[40]){
			if(Math.abs(char.xv)>0.001){
				char.rolling = true;
			}
			else
			{
				if(keysDown[32]){
					char.currentAnim = anim.spindash;
					char.animSpeed = 1;
					char.rolling = true;
				}
				else
				{
					char.currentAnim = anim.crouch;
				}
			}
		}
	}
	else
	{
		if(char.currentAnim != anim.spindash){
			char.currentAnim = anim.jump;
			char.animSpeed = Math.abs(char.xv/10);
			char.xv = (Math.abs(char.xv)-0.1)*(char.xv/Math.abs(char.xv));
			if(Math.abs(char.xv) < 0.2){
				char.rolling = false;
				char.xv = 0.0001*(char.xv/Math.abs(char.xv));
			}
		}
		else
		{
			if(keysDown[40] == false){
				char.currentAnim = anim.jump;
				char.xv = 15*(char.xv/Math.abs(char.xv));
			}
		}
	}
	if(char.grounded == false){
		char.currentAnim = anim.jump;
		char.animSpeed = Math.abs(char.xv/10)+0.3;
		char.angle /= 5;
	}
	//console.log(char.currentAnim);
	//console.log(char.xv)
	c.fillStyle = "black";
	/*
	for(var i = 0; i < char.currentAnim.length; i++){
		c.putImageData(char.currentAnim[i],i*char.currentAnim[0].width,0);
		c.fillRect(i*char.currentAnim[0].width,0,1,char.currentAnim[0].height);
	}*/
}

window.addEventListener("keydown",function(e){
	console.log(e.keyCode);
	keysDown[e.keyCode] = true;
});

window.addEventListener("keyup",function(e){
	keysDown[e.keyCode] = false;
});

//   ^ - 
// <   >
// |---| -- 32